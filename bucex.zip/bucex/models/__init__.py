"""Model specifications and compilation."""
from .base import LinearDesign, LinearGaussianSystem, StateSpaceModel
from .multiseries import Channel, MultiSeriesModel
from .shared import Shared, Departures
from ..dependence import GaussianCopula
from .multiseries_compiler import (
    CompiledMultiSeriesModel,
    compile_multiseries_model,
)
from .structural import Model, StructuralModel, StructuralSSM, structural_model

__all__ = [
    "LinearDesign",
    "LinearGaussianSystem",
    "StateSpaceModel",
    "Channel",
    "Shared",
    "Departures",
    "GaussianCopula",
    "MultiSeriesModel",
    "CompiledMultiSeriesModel",
    "compile_multiseries_model",
    "Model",
    "StructuralModel",
    "StructuralSSM",
    "structural_model",
]
