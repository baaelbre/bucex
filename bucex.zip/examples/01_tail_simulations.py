"""Simulate stationary matched GEV series while changing only shape or scale.

Every scenario has the same constant location. Matched probability draws make
shape or scale the only difference within each comparison. The model is
constructed directly with the public bucex API.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from copy import deepcopy
import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import genextreme

SOURCE_ROOT = Path(__file__).resolve().parents[1]
if (SOURCE_ROOT / "bucex").is_dir() and str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))
EXAMPLE_ROOT = Path(__file__).resolve().parent
if str(EXAMPLE_ROOT) not in sys.path:
    sys.path.insert(0, str(EXAMPLE_ROOT))

import bucex as bx


# Pick another JSON here for IDE/notebook runs; ``--config PATH`` overrides it.
DEFAULT_CONFIG_FILE = EXAMPLE_ROOT / "config" / "tail.json"
CONFIG_PARSER = argparse.ArgumentParser()
CONFIG_PARSER.add_argument("--config", type=Path, default=DEFAULT_CONFIG_FILE)
CONFIG_ARGUMENTS, _ = CONFIG_PARSER.parse_known_args()
SETTINGS_PATH = CONFIG_ARGUMENTS.config.expanduser().resolve()
CONFIG = bx.load_config(SETTINGS_PATH)
SETTINGS_FILE = Path(
    CONFIG.get("_runner", {}).get("source_config", SETTINGS_PATH)
).resolve()
SIMULATION = CONFIG["simulation"]
DENSITY = CONFIG["density"]
FIGURES = CONFIG["figures"]
OUTPUT = CONFIG["output"]

RESULTS_ROOT = Path(OUTPUT["results_root"])
SCRIPT_NAME = Path(__file__).stem
RUN_TIMESTAMP = OUTPUT.get("run_id") or datetime.now().strftime("%Y%m%d_%H%M%S")
OVERWRITE = bool(OUTPUT["overwrite"])

# Simulation design.
N_TIME = int(SIMULATION["n_time"])
START_DATE = str(SIMULATION["start_date"])
FREQUENCY = str(SIMULATION["frequency"])
LOCATION = SIMULATION["location"]
LOCATION_MODE = str(LOCATION["mode"]).lower()
LOCATION_VALUE = float(LOCATION["value"])
if LOCATION_MODE != "stationary":
    raise ValueError("Example 01 requires simulation.location.mode='stationary'.")

TAIL_SIGMA = float(SIMULATION["tail_sigma"])
TAIL_XI_VALUES = tuple(float(value) for value in SIMULATION["tail_xi_values"])
TAIL_SEED = int(SIMULATION["tail_seed"])

SCALE_SIGMA_VALUES = tuple(float(value) for value in SIMULATION["scale_sigma_values"])
SCALE_XI = float(SIMULATION["scale_xi"])
SCALE_SEED = int(SIMULATION["scale_seed"])

# The theoretical density plots show this central probability range. Their
# horizontal axis is y - mu; the shared location is constant at LOCATION_VALUE.
DENSITY_PROBABILITY_RANGE = tuple(float(value) for value in DENSITY["probability_range"])
DENSITY_GRID_POINTS = int(DENSITY["grid_points"])

FIGURE_FORMATS = tuple(FIGURES["formats"])
FIGURE_DPI = int(FIGURES["dpi"])
FIGURE_TITLES = dict(FIGURES.get("titles", {}))
COLORS = {"teal": "#1D7F7A", "grey": "#7A8589"}

RUN_SIGNATURE = f"n{N_TIME}_stationary_s{TAIL_SEED}-{SCALE_SEED}"
OUTPUT_DIR = RESULTS_ROOT / SCRIPT_NAME / f"{RUN_TIMESTAMP}__{RUN_SIGNATURE}"


# The one shared model makes the stationary location explicit. Scenario
# dictionaries below change observation parameters only.
STATIONARY_MODEL = bx.Model(
    bx.GEV(xi_bounds=(-0.5, 0.5)),
    (bx.LocalLevel(mode="static"),),
    name="stationary-location GEV",
)

TAIL_SCENARIOS = (
    {
        "name": "bounded_tail",
        "title": r"bounded tail ($\xi=-0.30$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": TAIL_SIGMA, "xi": TAIL_XI_VALUES[0]},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": TAIL_SEED,
    },
    {
        "name": "gumbel_tail",
        "title": r"exponential tail ($\xi=0$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": TAIL_SIGMA, "xi": TAIL_XI_VALUES[1]},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": TAIL_SEED,
    },
    {
        "name": "heavy_tail",
        "title": r"heavy tail ($\xi=+0.30$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": TAIL_SIGMA, "xi": TAIL_XI_VALUES[2]},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": TAIL_SEED,
    },
)

SCALE_SCENARIOS = (
    {
        "name": "low_scale",
        "title": r"low scale ($\sigma=0.75$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": SCALE_SIGMA_VALUES[0], "xi": SCALE_XI},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": SCALE_SEED,
    },
    {
        "name": "reference_scale",
        "title": r"reference scale ($\sigma=1.50$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": SCALE_SIGMA_VALUES[1], "xi": SCALE_XI},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": SCALE_SEED,
    },
    {
        "name": "high_scale",
        "title": r"high scale ($\sigma=3.00$)",
        "model": STATIONARY_MODEL,
        "params": {"sigma": SCALE_SIGMA_VALUES[2], "xi": SCALE_XI},
        "initial_state": np.array([LOCATION_VALUE]),
        "seed": SCALE_SEED,
    },
)


def main() -> None:
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "axes.titleweight": "bold", "legend.frameon": False})
    dates = pd.date_range(START_DATE, periods=N_TIME, freq=FREQUENCY)
    grouped_tables: dict[str, dict[str, pd.DataFrame]] = {"shape": {}, "scale": {}}
    grouped_scenarios = {"shape": TAIL_SCENARIOS, "scale": SCALE_SCENARIOS}

    config_path = OUTPUT_DIR / "run_config.json"
    if config_path.exists() and not OVERWRITE:
        raise FileExistsError(
            f"Refusing to overwrite {config_path}; change output.run_id or output.overwrite in the JSON."
        )
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    run_config = deepcopy(CONFIG)
    run_config.update({
        "script": SCRIPT_NAME,
        "created_at": datetime.now().astimezone().isoformat(),
        "run_timestamp": RUN_TIMESTAMP,
        "run_signature": RUN_SIGNATURE,
        "output_directory": str(OUTPUT_DIR),
        "bucex_version": bx.__version__,
        "settings_file": str(SETTINGS_FILE),
        "simulation": {
            "n_time": N_TIME,
            "start_date": START_DATE,
            "frequency": FREQUENCY,
            "location": {"mode": LOCATION_MODE, "value": LOCATION_VALUE},
            "tail_sigma": TAIL_SIGMA,
            "tail_xi_values": list(TAIL_XI_VALUES),
            "tail_seed": TAIL_SEED,
            "scale_sigma_values": list(SCALE_SIGMA_VALUES),
            "scale_xi": SCALE_XI,
            "scale_seed": SCALE_SEED,
        },
        "density": {
            "probability_range": list(DENSITY_PROBABILITY_RANGE),
            "grid_points": DENSITY_GRID_POINTS,
            "relative_to_location": True,
        },
        "figures": {
            "formats": list(FIGURE_FORMATS),
            "dpi": FIGURE_DPI,
            "titles": FIGURE_TITLES,
        },
    })
    bx.save_config(run_config, config_path)

    for group, scenarios in grouped_scenarios.items():
        for scenario in scenarios:
            simulation = bx.simulate(
                scenario["model"],
                N_TIME,
                scenario["params"],
                initial_state=scenario["initial_state"],
                seed=scenario["seed"],
            )
            level_index = scenario["model"].state_names.index("level")
            table = pd.DataFrame(
                {
                    "date": dates,
                    "y": simulation.y,
                    "eta": simulation.eta,
                    "level": simulation.states[1:, level_index],
                }
            )
            grouped_tables[group][scenario["name"]] = table

            data_path = OUTPUT_DIR / "simulations" / group / f"{scenario['name']}.csv"
            truth_path = data_path.with_suffix(".json")
            if not OVERWRITE and (data_path.exists() or truth_path.exists()):
                raise FileExistsError(f"Refusing to overwrite {data_path}; set output.overwrite=1.")
            data_path.parent.mkdir(parents=True, exist_ok=True)
            table.to_csv(data_path, index=False)
            truth = {
                "name": scenario["name"],
                "n_time": N_TIME,
                "model": scenario["model"].to_dict(),
                "params": scenario["params"],
                "initial_state": scenario["initial_state"].tolist(),
                "seed": scenario["seed"],
            }
            truth_path.write_text(json.dumps(truth, indent=2, sort_keys=True), encoding="utf-8")

    figure_dir = OUTPUT_DIR / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    for group, scenarios in grouped_scenarios.items():
        all_y = np.concatenate([grouped_tables[group][scenario["name"]]["y"].to_numpy() for scenario in scenarios])
        padding = 0.04 * max(float(np.ptp(all_y)), 1.0)
        common_ylim = (float(np.min(all_y) - padding), float(np.max(all_y) + padding))

        # One time series per figure. Within a group every figure has exactly
        # the same y range, so xi or sigma can be compared without rescaling.
        for scenario in scenarios:
            table = grouped_tables[group][scenario["name"]]
            figure, axis = plt.subplots(figsize=(11, 4.2))
            axis.scatter(table["date"], table["y"], s=7, alpha=0.27, color=COLORS["grey"], label=r"$y_t$")
            axis.plot(table["date"], table["eta"], color=COLORS["teal"], linewidth=1.8, label=r"$\mu_t$")
            axis.set_ylim(*common_ylim)
            time_series_title = bx.config_title(CONFIG, "time_series")
            if time_series_title is not None:
                axis.set_title(time_series_title.format(**scenario))
            axis.set_ylabel("GEV observation")
            axis.grid(axis="y", alpha=0.35)
            axis.legend(loc="upper left")
            figure.tight_layout()
            for extension in FIGURE_FORMATS:
                figure.savefig(figure_dir / f"{group}_{scenario['name']}.{extension}", dpi=FIGURE_DPI, bbox_inches="tight")
            plt.close(figure)

        # Compare the actual GEV densities, rather than kernel densities of the
        # simulated non-stationary observations.  SciPy uses c = -xi.  Setting
        # loc=0 makes the horizontal axis the value relative to mu_t.
        density_ranges = []
        finite_upper_endpoints = []
        for scenario in scenarios:
            sigma = float(scenario["params"]["sigma"])
            xi = float(scenario["params"]["xi"])
            density_ranges.append(
                genextreme.ppf(
                    DENSITY_PROBABILITY_RANGE,
                    c=-xi,
                    loc=0.0,
                    scale=sigma,
                )
            )
            if xi < 0.0:
                finite_upper_endpoints.append(-sigma / xi)

        lower = min(float(values[0]) for values in density_ranges)
        upper = max(float(values[1]) for values in density_ranges)
        if finite_upper_endpoints:
            upper = max(upper, max(finite_upper_endpoints))
        padding = 0.05 * max(upper - lower, 1.0)
        density_grid = np.linspace(lower - padding, upper + padding, DENSITY_GRID_POINTS)

        figure, axis = plt.subplots(figsize=(9, 4.6), layout="constrained")
        palette = ("#2778B4", COLORS["teal"], "#E76F51")
        for scenario, color in zip(scenarios, palette):
            sigma = float(scenario["params"]["sigma"])
            xi = float(scenario["params"]["xi"])
            density = genextreme.pdf(
                density_grid,
                c=-xi,
                loc=0.0,
                scale=sigma,
            )
            if group == "shape":
                label = rf"$\xi={xi:+.2f}$, $\sigma={sigma:.2f}$"
            else:
                label = rf"$\sigma={sigma:.2f}$, $\xi={xi:+.2f}$"
            if xi < 0.0:
                endpoint = -sigma / xi
                label += rf"; endpoint $={endpoint:.2f}$"
                axis.axvline(
                    endpoint,
                    color=color,
                    linestyle="--",
                    linewidth=1.25,
                    alpha=0.85,
                )
            axis.plot(
                density_grid,
                density,
                color=color,
                linewidth=2.2,
                label=label,
            )

        axis.set_xlim(lower - padding, upper + padding)
        density_title = bx.config_title(CONFIG, f"{group}_density")
        if density_title is not None:
            axis.set_title(density_title)
        axis.set_xlabel(r"value relative to location, $y-\mu$")
        axis.set_ylabel("density")
        axis.grid(axis="y", alpha=0.35)
        axis.legend()
        for extension in FIGURE_FORMATS:
            figure.savefig(
                figure_dir / f"{group}_density_comparison.{extension}",
                dpi=FIGURE_DPI,
                bbox_inches="tight",
            )
        plt.close(figure)

    catalog = []
    for group, scenarios in grouped_scenarios.items():
        for scenario in scenarios:
            catalog.append({"group": group, "name": scenario["name"], **scenario["params"], "seed": scenario["seed"]})
    catalog_path = OUTPUT_DIR / "tables" / "scenarios.csv"
    catalog_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(catalog).to_csv(catalog_path, index=False)
    print(f"Tail and scale outputs: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
