# bucex 1.5.2 examples

The 13 numbered files are direct uses of the public `bucex` API. Examples 10
and 11 cover GEV log-scale sensitivity; example 12 completes the primary
six-series Uccle analysis:

1. `00_uccle_record.py` — Uccle record and LOESS summaries.
2. `01_tail_simulations.py` — stationary matched GEV shape/scale comparisons.
3. `02_structural_simulations.py` — six structural data-generating models.
4. `03_simulation_laplace.py` — structural recovery with Laplace.
5. `04_simulation_pgas.py` — structural recovery with PGAS.
6. `05_uccle_laplace.py` — Uccle Laplace fits.
7. `06_uccle_pgas.py` — Uccle PGAS fits.
8. `07_centered_ig.py` — centered inverse-gamma benchmark.
9. `08_simulation_laplace_mh.py` — exact Laplace-MH simulations.
10. `09_uccle_laplace_mh.py` — exact Laplace-MH Uccle fits.
11. `10_simulation_phi.py` — stationary/linear/RW/SSVS log-scale sensitivity.
12. `11_uccle_phi.py` — the four scale models for each Uccle series.
13. `12_uccle_gaussian.py` — exact Gaussian FFBS for Uccle TXm and TNm.

## Pick a JSON

Every script exposes `DEFAULT_CONFIG_FILE` near the top and accepts
`--config PATH`. Examples 10, 11, and 12 have one `main()` and read the
selected JSON directly; there is no configuration wrapper and no hidden
scientific environment-variable layer.

For an IDE run, edit one line:

```python
DEFAULT_CONFIG_FILE = Path(__file__).parent / "config" / "phi" / "simulation_rw.json"
```

For a terminal run, leave the file untouched:

```bash
python examples/10_simulation_phi.py --config examples/config/phi/simulation_rw.json
```

## Stationary tail comparisons

Example 01 uses a constant location and matched probability draws. Only shape
changes in the first group, and only scale changes in the second:

```bash
python examples/01_tail_simulations.py --config examples/config/tail.json
```

Edit `simulation.location.value` to move the common location. Its mode is
deliberately fixed to `"stationary"`; there is no location process-SD setting.

## Simulation scale sensitivity

The supplied simulation files share a stationary data-generating truth and
fit four alternative scale models. This is a clean sensitivity comparison:

```bash
python examples/10_simulation_phi.py --config examples/config/phi/simulation_stationary.json
python examples/10_simulation_phi.py --config examples/config/phi/simulation_linear.json
python examples/10_simulation_phi.py --config examples/config/phi/simulation_rw.json
python examples/10_simulation_phi.py --config examples/config/phi/simulation_ssvs.json
```

To simulate a changing scale as well, edit `simulation.phi.mode` in a copy of
the JSON to `"linear"` or `"rw"`. The same object contains
`linear_change`, `rw_sd`, and `reference_sigma`; all three remain visible even
when inactive so switching experiments is easy.

The two location structures are explicit too. `simulation.location` is the
data-generating truth; `model.location` is the fitted structural-SSVS model.
In particular, the `linear` in `simulation_linear.json` refers to
`model.phi`, while its supplied `simulation.phi.mode` remains `stationary`.
Every phi JSON contains valid `_comment` fields. Read
[`config/phi/README.md`](config/phi/README.md) for the equations and a complete
field guide.

## Uccle scale sensitivity

There are four readable JSONs per series under `config/phi/uccle/`:

| Series | Stationary | Linear | Random walk | SSVS |
|---|---|---|---|---|
| TXx | `01_txx_stationary.json` | `01_txx_linear.json` | `01_txx_rw.json` | `01_txx_ssvs.json` |
| TXn | `02_txn_stationary.json` | `02_txn_linear.json` | `02_txn_rw.json` | `02_txn_ssvs.json` |
| TNx | `03_tnx_stationary.json` | `03_tnx_linear.json` | `03_tnx_rw.json` | `03_tnx_ssvs.json` |
| TNn | `04_tnn_stationary.json` | `04_tnn_linear.json` | `04_tnn_rw.json` | `04_tnn_ssvs.json` |

Run one directly:

```bash
python examples/11_uccle_phi.py --config examples/config/phi/uccle/04_tnn_ssvs.json
```

Run all 16 sequentially in a local shell:

```bash
for config in examples/config/phi/uccle/*.json; do
  python examples/11_uccle_phi.py --config "$config"
done
```

For local four-chain process parallelism, use the Bash wrappers:

```bash
bash bash_scripts/run_10_simulation_phi.sh examples/config/phi/simulation_rw.json 4
bash bash_scripts/run_11_uccle_phi.sh examples/config/phi/uccle/01_txx_ssvs.json 4
```

## Uccle monthly means

TXm and TNm are monthly means rather than monthly extremes, so they use a
Gaussian observation equation and exact FFBS. Their local-linear trend,
dummy-seasonal structure, SSVS probabilities, and primary innovation slabs
match the primary extreme-temperature analysis.

```bash
python examples/12_uccle_gaussian.py --config examples/config/uccle_gaussian/01_txm.json
python examples/12_uccle_gaussian.py --config examples/config/uccle_gaussian/02_tnm.json

bash bash_scripts/run_12_uccle_gaussian.sh examples/config/uccle_gaussian/01_txm.json 4
```

There are no particles or Laplace tuning fields in these two JSONs. Change
priors, MCMC, figures, predictions, or output values directly in the selected
file.

## Seasonal patterns at selected years

The fitting examples still write `season.*`, where each month is followed
through the complete record. They now also write `seasonal_patterns.*`, with
months on the horizontal axis and one line per selected year. Uccle JSONs use:

```json
"seasonal_patterns": {
  "years": [1892, 2022],
  "cycles": [],
  "show_interval": true
}
```

Edit `years` to any complete years in the fitted record; three or more years
are allowed. Set `years` to `[]` to suppress the figure. Simulation JSONs use
`"cycles": ["first", "last"]` instead. The bands use the probability in
`figures.interval_probability`.

To add the figure to an existing run without refitting, use the unnumbered
reporting script:

```bash
python examples/replot_seasonal_patterns.py \
  /path/to/first/completed-run /path/to/second/completed-run \
  --years 1892 2022
```

It requires `fits/<series>/combined.bucex`; a lightweight `figures.zip` alone
does not contain the posterior draws needed to construct a new figure.

## What to edit

All scale hyperparameters are grouped under `priors.phi`:

```json
"phi": {
  "linear": {"mean": 0.0, "sd": 0.35},
  "rw_variance": {"a": 2.5, "b": 0.0000375},
  "model_probabilities": {"stationary": 0.5, "linear": 0.25, "rw": 0.25}
}
```

- `linear` is the prior for the whole-record change in log scale.
- `rw_variance` is an inverse-gamma prior in the package's `IG(a,b)`
  convention.
- `model_probabilities` are used only by `model.phi: "ssvs"` and must sum to
  one.
- `priors.sigma2` controls the stationary scale or the initial/reference scale
  of a dynamic model.
- `inference.phi` contains proposal and Laplace-smoother tuning only.
- `mcmc` contains draws, warmup, thinning, chain count, and seed.
- `figures` contains the interval, predictive draws, forecast horizon, focus
  phase/month, output formats, and optional diagnostics.

The production JSONs use 1,000 retained draws, 1,000 warmup iterations, and
four chains. The PBS scripts never replace these values. The chain runner
creates temporary one-chain copies only to execute the four requested chains
concurrently, then combines them.

## Outputs

Outputs are stored below:

```text
results/10_simulation_phi/<run-id>__<signature>/
results/11_uccle_phi/<run-id>__<signature>/
results/12_uccle_gaussian/<run-id>__<signature>/
```

Each run saves the exact effective `run_config.json`, one or more `.bucex`
fits, and the established full report: parameter and MCMC diagnostics,
location trajectories, structural selection, posterior predictive checks,
forecasts, latent states, process scales, and GEV figures. Phi paths, scale
paths, and scale-model probabilities are additional tables and figures rather
than replacements for the older outputs. Automatic Bash/PBS run IDs contain
the source configuration name plus process or PBS job ID, so parallel series
and model jobs do not collide. Leave `output.run_id` as `null` unless you
deliberately provide a unique name.

See `../docs/HPC.md` for PBS commands and `../docs/LOG_SCALE.md` for the model
and inference details.
