# Release and scientific validation

Release 1.5.2 has five software layers:

1. unit/integration tests for models, priors, engines, results, and archives;
2. fixed-seed numerical regression in `validation/run_release_validation.py`;
3. focused direct-API Laplace-to-PGAS smoke validation;
4. source compilation plus wheel/source builds;
5. installed-wheel import and CLI checks.

```bash
python -m pytest
python validation/run_release_validation.py
python validation/run_example_smoke.py
python -m build
```

Short validation chains establish software behavior only. They are not
evidence for a scientific conclusion.

## Release gates

- `import bucex as bx` exposes the documented modelling, inference, result,
  simulation, data, and plotting APIs;
- packaging is declared only in `pyproject.toml`, current validation files use
  release-neutral names, and historical generated validation JSONs are absent;
- Laplace plans remain explicitly approximate; Laplace-MH and PGAS plans are
  exact-invariant;
- quadratic-observation Laplace-MH proposals accept with constant correction
  weights, and singular FS recursions hold exactly after projection;
- negative-shape GEV proposal construction repairs an invalid zero FS path
  deterministically, including when only an integrated slope moves the
  predictor;
- exact samplers abort before recording restored or duplicate draws after an
  unrecoverable numerical exception;
- a univariate Laplace `FitResult` exports a compatible full-path warm start;
- PGAS metadata records that Laplace supplied the initializer;
- singular-support ancestor calculations remain finite and keep the
  conditioned predecessor available;
- the reference-ancestor change metric is stored, summarized, and exported;
- lower-tail Uccle fits round-trip observations in their original orientation;
- every tail/scale demonstration has an exactly constant predictor and no
  process-innovation parameter;
- tail scenarios use matched probability draws and vary only shape over
  `-0.30/0/+0.30`;
- scale scenarios use matched probability draws and `xi=-0.30`, varying only
  `sigma=0.75/1.50/3.00`;
- `GEV()` remains identical to `GEV(phi="stationary")`, while model
  serialization preserves `linear`, `rw`, and `ssvs` declarations;
- analytic GEV derivatives with respect to `phi=log(sigma)` agree with finite
  differences for negative, zero, and positive shape;
- stationary, linear, random-walk, and SSVS scale models complete exact
  Laplace-MH smoke fits and expose uniform `phi_draws()`/`sigma_draws()` paths;
- RW log-scale proposals receive an exact independence-MH correction under
  Laplace-MH and PGAS, while ordinary Laplace remains explicitly approximate;
- scale SSVS probabilities sum to one, indicators are stored, and scale-model
  selection is separate from structural SSVS;
- every phi JSON remains strict JSON, carries ignored `_comment` annotations,
  and declares the fitted location structure under `model.location`;
- simulation phi JSONs separately declare the data-generating location under
  `simulation.location`, so location truth is not hidden in Python;
- posterior predictive simulation uses the in-sample scale path; forecasts
  hold, extend, propagate, or model-average scale according to `phi=`;
- the six period-4 structural scenarios share scale/shape and cover stationary,
  linear-trend, random-walk, local-linear-trend, dynamic-seasonal, and
  fixed-seasonal truths;
- examples 08 and 09 match examples 03 and 05 respectively in scientific
  settings, priors, MCMC defaults, output tables, and figures, changing only
  the exact Laplace-MH state engine and its diagnostics;
- examples 10 and 11 preserve those established core report tables, figures,
  and fit-directory layout while adding phi paths and scale-model summaries;
- example 12 uses only the public Gaussian/SSVS/FFBS API and preserves the
  established Uccle table, figure, prediction, and fit-directory layout;
- selected-year and selected-cycle seasonal-pattern plots recover the correct
  posterior seasonal slices, preserve original lower-tail orientation, and
  reject incomplete or mismatched selectors;
- timestamped paths and overwrite behavior are declared in each selected JSON
  configuration;
- independently saved chains combine only when model, prior, plan, data, and
  dates agree;
- the generic HPC runner creates one JSON copy per chain, launches independent
  chains concurrently, and combines them only after every process succeeds;
- automatic run IDs distinguish simultaneous configurations and PBS jobs, and
  every manifest records the original selected JSON rather than a temporary
  chain copy;
- four calibrated one-series GEV JSONs and two Gaussian mean JSONs encode the
  primary six-series model, slabs, structural probabilities, and four-chain
  settings;
- schema-2.7.0 archives round-trip dynamic-scale paths and all older supported
  archives remain readable;
- the 13 Python examples are self-contained calls to the public API;
- centered inverse-gamma process variances use their exact Gibbs full
  conditional and are labelled `inverse_gamma_gibbs` in diagnostics;
- the centered/inverse-gamma benchmark defaults to approximate Laplace for
  speed, disables ASIS, and selects Laplace-MH or PGAS through
  `examples/config/centered_ig.json`;
- the 13 ordinary PBS jobs invoke those same examples, and every fitting
  workflow combines independent chains only after all chain processes or array
  tasks succeed;
- dedicated level and slope figures keep observations off the slope scale;
- LOESS and seasonal-component plots satisfy their numerical contracts;
- posterior predictive replication and forecast plots preserve dates, tail
  orientation, and observation scale;
- Uccle slope figures use the requested per-decade scale and conditional
  fixed/dynamic overlays.

## Manuscript and presentation gates

- at least four independent chains for each reported posterior;
- stable conclusions after increasing PGAS particles;
- satisfactory R-hat/ESS for continuous summaries;
- adequate structural allocation switching, not only continuous diagnostics;
- reported particle ESS, unique ancestors, path-update fraction, and
  reference-ancestor change;
- zero unexplained restoration failures and valid GEV support;
- prior predictive checks and defensible model odds/slab calibration;
- simulation recovery for every advertised structural state;
- sensitivity to record start, process slabs, shape bounds, and particle count;
- sensitivity to stationary, linear, RW, and SSVS log scale plus their prior
  hyperparameters;
- model-averaged trajectories and risk summaries rather than hard-selected
  post-fit models;
- archived config, version, seeds, manifest, fits, tables, and figures.

For selection recovery, inspect both the probability assigned to the true
state and whether chains actually move between plausible structures. A high
true-state probability from a chain that never switched is not sufficient
validation.
